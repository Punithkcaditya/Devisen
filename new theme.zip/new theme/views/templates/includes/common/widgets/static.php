<?php
echo $w->widget_content;
?>
<!-- Quotes Area End -->