<?php
$line = $w->widget_content;
?>
<!-- Quotes Area End -->