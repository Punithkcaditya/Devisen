<?php $this->load->view('templates/includes/common/widgetarea_1'); ?>
<?php $this->load->view('templates/includes/common/widgetarea_2'); ?>
<?php $this->load->view('templates/includes/common/widgetarea_3'); ?>
<?php $this->load->view('templates/includes/common/commentry'); ?>
<?php $this->load->view('templates/includes/common/widgetarea_4'); ?>
<?php $this->load->view('templates/includes/common/widgetarea_5'); ?>
