<div class="grid-row">
    <?php $this->load->view($view_path); ?>
</div>