<!DOCTYPE html>
<html lang="en">
    <?php $this->load->view('templates/includes/common/header'); 
    
    ?>
    <body>
        <?php $this->load->view('templates/includes/common/header_menu'); ?>
        <?php $this->load->view('templates/includes/common/breadcromb'); ?>
        <?php $this->load->view('templates/includes/inner_page_body'); ?>
        <?php $this->load->view('templates/includes/common/footer_home'); ?>
        <?php $this->load->view('templates/includes/common/scripts'); ?>
    </body>
</html>