<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Banners_Model extends CI_Model {

    private $table;
    public $primary_key;
    public $data;

    function __construct() {
        parent::__construct();
        $this->table = substr(strtolower(get_class($this)), 0, -6);
        $this->primary_key = array();
        $this->data = array();
    }

    private function reset() {
        $this->primary_key = array();
        $this->data = array();
    }
         
    private function reset_pk() {
        $this->primary_key = array();
    }
    
    private function reset_data() {
        $this->data = array();
    }

    public function get_max_value($field) {
        $this->db->select_max($field);
        $query = $this->db->get($this->table);
        $row = $query->row();
        return $row->$field;
    }

    public function get_row() {
        $this->db->where($this->primary_key);
        $query = $this->db->get($this->table);
        $row = $query->row();
        $this->reset_pk();
        return $row;
    }

    public function view() {
        $this->db->order_by('display_order ASC');
        $this->db->where('status_ind', 1);
        //$this->db->where('banner_for', 0);
        $query = $this->db->select('*')->from($this->table)->get();
        return $query->result();
    }
    
    public function mobile_view() {
        //$this->db->order_by('display_order ASC,last_modified_date DESC');
        $this->db->order_by('created_date DESC');
        $this->db->where('status_ind', 1);
        $this->db->where('banner_for', 1);
        $query = $this->db->select('*')->from($this->table)->get();
        return $query->result();
    }

}
